plugins {
    id("com.android.application") version "8.11.1" apply false   // AGP 8.11 builds against Android 16 (API 36)
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
