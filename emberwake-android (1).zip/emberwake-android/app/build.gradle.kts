plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.emberwake.game"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.emberwake.game"
        minSdk = 26          // Android 8.0 and newer
        targetSdk = 36          // Android 16 (API 36): required by Google Play for new apps and updates since 31 Aug 2026
        versionCode = 147
        versionName = "1.47"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            // Sign with the debug key so a release build installs right away.
            // Replace this with your own keystore before publishing on Google Play.
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += listOf("html") }
}
